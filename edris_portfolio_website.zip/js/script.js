// script.js

// Dark Mode Toggle
const toggle = document.getElementById('darkModeToggle');
const body = document.getElementById('main-body');

// Load saved mode
if (localStorage.getItem('dark-mode') === 'enabled') {
  body.classList.add('dark-mode');
}

toggle.addEventListener('click', () => {
  body.classList.toggle('dark-mode');
  const mode = body.classList.contains('dark-mode') ? 'enabled' : 'disabled';
  localStorage.setItem('dark-mode', mode);
});

// Scroll-based fade-in animation
const fadeInElements = document.querySelectorAll('.animate-fade-in');
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('opacity-100');
    }
  });
}, { threshold: 0.1 });

fadeInElements.forEach(el => {
  el.classList.add('opacity-0');
  observer.observe(el);
});
