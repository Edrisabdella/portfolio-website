# Edris Abdella - Portfolio Website

This is a personal portfolio website for Edris Abdella, a software developer with a background in Construction Technology and Management.

## 🚀 Live Demo

Once hosted, you can access it here:  
👉 `https://your-username.github.io/portfolio-website/`

## 🛠️ Technologies Used

- HTML5, CSS3
- Tailwind CSS
- Bootstrap
- JavaScript

## 💻 Project Structure

```
portfolio-website/
├── index.html
├── css/
│   └── styles.css
├── js/
│   └── script.js
├── images/
│   └── profile.jpg
```

## 🔧 How to Use

1. Clone the repo or download the ZIP.
2. Place your profile image as `images/profile.jpg`.
3. Customize the content.
4. Upload to GitHub and enable GitHub Pages.

## 📄 License

This project is licensed under the MIT License.
